# H960RM v1 -> v2: changes made after the previous independent review (2026-10-17)

The previous review's findings and what v2 does about each. The code changes are in builder/student_leg.py, function
harden(), and builder/build_h960.py. The pushed and submitted H960 / H958M were NOT changed: they still rebuild byte-identically.

| Finding | v1 | v2 |
|---|---|---|
| F1: the fallback is not the scored 0.958 | Docs and receipt said "0.958 baseline kept". | The fallback is named the **parent snapshot**. The snapshot cell stores PARENT_LABEL, and for H960RM it says "the 0.958 notebook's cells + nartaa's 224 anatomical mirror (the H958M parent, NOT the scored 0.958 file)". The receipt records parent and parent_sha256. |
| F2: %%writefile outside the guard | 4 cells (makedirs + 3 %%writefile) were unguarded. | One guarded Python writer cell writes the same three files (same contents, R3 included). A failure leaves READER_SRC_OK False, and the run cell then skips the stage. |
| F3: decoder coverage | pip check=False; pylibjpeg-libjpeg fails to install. | Unchanged on purpose. The same decoder limitation was present in every scored student run (the 0.955/0.957 observations), so a hard coverage gate would change the validated configuration. pip_rc is recorded. Hidden-run logs are not visible to us anyway. |
| F4: no single hard deadline | One check (≥45 min) before inference, plus the subprocess timeout. | Adds a check at the start of the stage (≥50 min left, before asset lookup and hashing). The ≥45 min check before inference and the timeout max(60, 9h−elapsed−20min) remain. R6 has its own deadline of 8.3 h from notebook start. |
| F5: final-cell setup and receipt unguarded | Snapshot copy and parent read sat before `try`; receipt write was unguarded. | Setup is inside `try`. The receipt write is in its own try/except: a failure prints RECEIPT_WRITE_FAILED and keeps the valid blend. |
| F6: dead imputation branch | Present (inert). | Removed. |
| F8: partial baseline hash | The builder checked 12 hex characters. | The builder checks the full sha256 00ca614beec23736346df921e3305742bf8533b7cfd69a208880022f899fa1d7. |
| History claim | "The same 5-student add-on gave +0.001 twice." | Corrected: H955C had 1 student (0.954→0.955), H957 3 students (0.956→0.957), and H957x5 5 students with the displayed score unchanged (0.957). |

## v2 cell layout (15 cells)
- c0–c8: the baseline. c2, c3, c6, c7 and c8 are byte-identical; c4/c5 carry the 224 mirror (H960RM only); c0 is the title.
- c9: parent snapshot (sha256).
- c11: guarded source writer.
- c12: guarded student run.
- c14: strict final cell.
- c10 and c13: markdown.

## Tests
tests/test_h960r.py runs on fake data with a mocked subprocess. tests/test_output_v2.txt holds a real run on both v2 drafts: 18 cases, all pass.
- Part A (10 cases): the blend math; byte-identical parent restore for 9 invalid or failed cases; a receipt-write failure.
- Part B (8 cases): the guarded run cell. Cases: normal, real-sha mismatch, missing checkpoint, wrong data, late, timeout, source-writer failure, late start.

These tests do NOT cover real DICOM decoding, real Kaggle mounts, GPU memory or full hidden-test runtime.

## Status at packing time
- 57281541 (H960, students only, v1 code) and 57281543 (H958M, mirror only) were submitted 2026-10-16 19:51 UTC and are pending.
- Their commit runs (3 visible studies) passed; the logs are in evidence/.
- The v2 drafts have not been pushed, committed on Kaggle, or submitted.
